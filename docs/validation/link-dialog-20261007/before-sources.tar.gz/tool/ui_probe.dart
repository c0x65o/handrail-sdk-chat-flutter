// Qualification-only entrypoint: retain the complete Workspace/ThreadView in
// release compilation as well as the separately exercised composer probe.
import 'package:flutter/material.dart';
import 'package:handrail_chat/ui.dart';
import 'toolbar_probe.dart' as probe;

void main() {
  if (Uri.base.queryParameters['workspace'] == 'on') {
    final client = HandrailChatClient(
      apiBaseUri: Uri.parse('https://fixture.invalid/api/chat'),
      tokenProvider: () async => 'fixture-only',
      transport: probe.ProbeTransport(),
    );
    runApp(MaterialApp(home: ChatScope(client: client,
      child: const Scaffold(body: HandrailChatWorkspace()))));
  } else {
    probe.main();
  }
}
